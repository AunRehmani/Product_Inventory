package org.example.services;
import org.example.*;
import java.sql.SQLException;
import java.util.Scanner;

public class Product_service {
    private Product_DAO dao;
    private Scanner scan;
    private barcode_service barcode_serve;

    public Product_service(){
        this.dao=new Product_DAO();
        this.barcode_serve=new barcode_service();
        this.scan= new Scanner(System.in);
    }
    public void addProduct() {
        try {
            System.out.println("\n--- Add New Product ---");

            System.out.println("Enter product id");
            int id= Integer.parseInt(scan.nextLine());

            String barcode = barcode_serve.generateBarcode();
            System.out.println("Generated Barcode: " + barcode);

            System.out.print("Enter product name: ");
            String name = scan.nextLine();

            System.out.print("Enter product price: ");
            double price = Double.parseDouble(scan.nextLine());

            System.out.print("Enter product quantity: ");
            int quantity = Integer.parseInt(scan.nextLine());

            System.out.print("Enter product brand: ");
            String brand = scan.nextLine();

            System.out.print("Enter product quality: ");
            String quality = scan.nextLine();

            System.out.print("Enter product manufacture date: ");
            String manufacture_date = scan.nextLine();

            System.out.print("Enter product catogrey: ");
            String catogrey = scan.nextLine();

            Product product = new Product(id,barcode, name, price, quantity,brand,quality,manufacture_date,catogrey);
            dao.insert_product(product);
            System.out.println("Product added successfully!");

        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

    public void searchProductByBarcode() {
        System.out.print("\nEnter barcode to search: ");
        String barcode = scan.nextLine();

        try {
            Product product = dao.getProductByBarcode(barcode);
            if (product != null) {
                System.out.println(product);
            } else {
                System.out.println("Product not found with barcode: " + barcode);
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void updateProduct() {
        System.out.print("\nEnter barcode of product to update: ");
        String barcode = scan.nextLine().trim();

        try {
            // First verify product exists
            Product product = dao.getProductByBarcode(barcode);
            if (product == null) {
                System.out.println("Error: No product found with barcode: " + barcode);
                return;
            }

            // Display current values
            System.out.println("\nCurrent product details:");
            System.out.println("Name: " + product.getName());
            System.out.println("Current Price: " + product.getPrice());
            System.out.println("Current Quantity: " + product.getQuantity());

            // Get updated values
            System.out.print("\nEnter new price (press Enter to keep current): ");
            String priceInput = scan.nextLine();
            if (!priceInput.isEmpty()) {
                product.setPrice(Double.parseDouble(priceInput));
            }

            System.out.print("Enter new quantity (press Enter to keep current): ");
            String qtyInput = scan.nextLine();
            if (!qtyInput.isEmpty()) {
                product.setQuantity(Integer.parseInt(qtyInput));
            }

            // Perform the update
            dao.update_product(product);
            System.out.println("\nSuccessfully updated product: " + product.getName());

        } catch (SQLException e) {
            System.out.println("\nDatabase error: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("\nInvalid number format: " + e.getMessage());
        }
    }

    public void deleteProduct() {
        System.out.print("\nEnter barcode of product to delete: ");
        String barcode = scan.nextLine();

        try {
            Product product = dao.getProductByBarcode(barcode);
            if (product == null) {
                System.out.println("Product not found!");
                return;
            }

            System.out.println("You are about to delete:");
            System.out.println(product);
            System.out.print("Are you sure? (y/n): ");

            if (scan.nextLine().equalsIgnoreCase("y")) {
                dao.delete_product(barcode);
                System.out.println("Product deleted successfully!");
            } else {
                System.out.println("Deletion cancelled.");
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    public void displayAllProducts() {
        try {
            dao.displayAllProducts();
        } catch (SQLException e) {
            System.out.println("Error displaying products: " + e.getMessage());
        }
    }

}




