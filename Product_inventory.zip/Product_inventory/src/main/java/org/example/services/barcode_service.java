package org.example.services;

import java.util.Random;

public class barcode_service {
    private static final String PREFIX = "BRC";
    private static final int DIGITS = 10;
    private final Random random = new Random();

    public String generateBarcode() {
        StringBuilder barcode = new StringBuilder(PREFIX);
        for (int i = 0; i < DIGITS; i++) {
            barcode.append(random.nextInt(10));
        }
        return barcode.toString();
    }
}