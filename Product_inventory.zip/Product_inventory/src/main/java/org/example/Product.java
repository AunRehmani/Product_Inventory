package org.example;

public class Product {

        private int id;
        private String barcode;
        private String name;
        private double price;
        private int quantity;
        private String brand;
        private String quality;
        private String manufacture_date;
        private String catogery;


        public Product(int id,String barcode, String name, double price, int quantity,String brand,String quality,String manufacture_date,String catogery) {
            this.id=id;
            this.barcode = barcode;
            this.name = name;
            this.price = price;
            this.quantity = quantity;
            this.brand=brand;
            this.quality=quality;
            this.manufacture_date=manufacture_date;
            this.catogery=catogery;
        }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getBrand() {
        return brand;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public String getQuality() {
        return quality;
    }

    public void setManufacture_date(String manufacture_date) {
        this.manufacture_date = manufacture_date;
    }

    public String getManufacture_date() {
        return manufacture_date;
    }

    public void setCatogery(String catogery) {
        this.catogery = catogery;
    }

    public String getCatogery() {
        return catogery;
    }

    @Override
    public String toString() {
        return String.format("ID: %d | Barcode: %s | Name: %s | Brand:%s | Price: $%8.2f | Qty: %d | Quality: %s",
                id, barcode, name, brand, price, quantity,quality);
    }
}
