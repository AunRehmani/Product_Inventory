package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import org.example.services.Product_service;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Product_service productService = new Product_service();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Barcode Inventory System ===");
            System.out.println("1. Add New Product");
            System.out.println("2. View All Products");
            System.out.println("3. Search Product by Barcode");
            System.out.println("4. Update Product");
            System.out.println("5. Delete Product");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            try {
                int choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1 -> productService.addProduct();
                    case 2 -> productService.displayAllProducts();
                    case 3 -> productService.searchProductByBarcode();
                    case 4 -> productService.updateProduct();
                    case 5 -> productService.deleteProduct();
                    case 6 -> {
                        System.out.println("Exiting system. Goodbye!");
                        System.exit(0);
                    }
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}