package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class db_connection {

    private static final String URL= "jdbc:mysql://localhost:3306/product_inventory";
    private static final String User= "root";
    private static final String pass= "admin";

    public static Connection getconnect() throws SQLException{
        return DriverManager.getConnection(URL,User,pass);
    }


}
