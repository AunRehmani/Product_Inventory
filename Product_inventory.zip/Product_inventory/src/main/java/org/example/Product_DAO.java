package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Product_DAO {

    public void insert_product(Product pro) {
        String sql = "INSERT INTO products (id,barcode,name,price,quantity,brand,quality,manufacture_date,catogrey) VALUES (?, ?, ?,?,?,?,?,?,?)";

        try (Connection conn = db_connection.getconnect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, pro.getId());
            stmt.setString(2, pro.getBarcode());
            stmt.setString(3, pro.getName());
            stmt.setDouble(4, pro.getPrice());
            stmt.setInt(5, pro.getQuantity());
            stmt.setString(6, pro.getBrand());
            stmt.setString(7, pro.getQuality());
            stmt.setString(8, pro.getManufacture_date());
            stmt.setString(9, pro.getCatogery());
            int row = stmt.executeUpdate();
            System.out.println("inserted " +pro.getName()+ " in products");
        } catch (SQLException e) {
            System.out.println("insertion fail try again");
            e.printStackTrace();
        }
    }


    public void delete_product(String barcode) {
        String sql = "DELETE FROM products WHERE barcode = ?";
        try (Connection conn = db_connection.getconnect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, barcode);
            int row = stmt.executeUpdate();

            if (row > 0) {
                System.out.println("product deleted containing barcode " + barcode);

            } else {
                System.out.println("no product containing id " + barcode);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public void update_product(Product pro) throws SQLException {
        // Correct SQL with one SET clause
        String sql = "UPDATE products SET quantity = ?, price = ? WHERE barcode = ?";

        try (Connection conn = db_connection.getconnect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // MUST SET PARAMETERS BEFORE EXECUTING
            stmt.setInt(1, pro.getQuantity());      // First ? (quantity)
            stmt.setDouble(2, pro.getPrice());      // Second ? (price)
            stmt.setString(3, pro.getBarcode());    // Third ? (WHERE condition)

            // Now execute the update
            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated == 0) {
                throw new SQLException("No product found with barcode: " + pro.getBarcode());
            }
        }
    }

    public Product getProductByBarcode(String barcode) throws SQLException {
        String sql = "SELECT * FROM products WHERE barcode = ?";

        try (Connection conn = db_connection.getconnect();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, barcode);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Product pro = new Product(
                            rs.getInt("id"),
                            rs.getString("barcode"),
                            rs.getString("name"),
                            rs.getDouble("price"),
                            rs.getInt("quantity"),
                            rs.getString("brand"),
                            rs.getString("quality"),
                            rs.getString("manufacture_date"),
                            rs.getString("catogrey")
                    );

                    return pro;
                }
            }
        }
        return null;
    }

    public void displayAllProducts() throws SQLException {
        String sql = "SELECT * FROM products";

        try (Connection conn = db_connection.getconnect();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery(sql)) {

            System.out.println("\n=== ALL PRODUCTS ===");
            System.out.println("ID\tBarcode\t\tName\t\tPrice\tQuantity");
            System.out.println("------------------------------------------------");

            while (rs.next()) {
                // Print each product directly from ResultSet
                System.out.printf("%d\t%s\t%s\t$%.2f\t%d%n",
                        rs.getInt("id"),
                        rs.getString("barcode"),
                        rs.getString("name"),
                        rs.getDouble("price"),
                        rs.getInt("quantity"));
            }
        }
    }
}